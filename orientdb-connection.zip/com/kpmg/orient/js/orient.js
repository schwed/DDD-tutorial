

//var orientdb = new ODatabase('http://USMDCKDDB6042:2480/VisualDNS');
//orientdb.open('root', 'Genie.2013');

//var orientdbInfo = orientdb.open('root', 'Genie.2013');

//var schemaInfo = orientdb.schema();
//alert('SCHEMA INFO: ' + JSON.stringify(schemaInfo));
//alert('DB INFO: ' + JSON.stringify(orientdbInfo));


var jsonData = orientdb.query('select expand(out()) from System');
var jsonString = JSON.stringify(jsonData);

alert(jsonString);


orientdb.close();
