/**
 * Created by kshevchuk on 7/7/2015.
 */

var orientdb = new ODatabase('http://USMDCKDDB6042:2480/VisualDNS');
orientdb.open('root', 'Genie.2013');
