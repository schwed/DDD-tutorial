

var orientdb = new ODatabase('http://USMDCKDDB6042:2480/StanDB');
orientdb.open('root', 'Genie.2013');

//var orientdbInfo = orientdb.open('root', 'Genie.2013');

//var schemaInfo = orientdb.schema();
//alert('SCHEMA INFO: ' + JSON.stringify(schemaInfo));
//alert('DB INFO: ' + JSON.stringify(orientdbInfo));

var ouser = orientdb.query('SELECT FROM OUser');
alert(JSON.stringify(ouser));

orientdb.close();
