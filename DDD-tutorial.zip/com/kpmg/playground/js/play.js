/**
 * Created by kshevchuk on 6/25/2015.
 */

var svg = createSVG();

/**
 * associate each circle with unique ID so that exit() and updates properly effect the correct element.
 */
var circle = svg.selectAll("circle").data($data, f('id'));
circle.enter().append('circle')
    .attr('opacity', 0)
    .attr('class', f('sex'))
    .attr("cx", f('height'))
    .attr("cy", f('age'));

circle.transaction().duration(300)
    .attr('opacity', 0.6)
    .attr('r', function(d) { return Math.pow(bmi(d), 3)/15000})
    .attr("cx", f('height'))
    .attr("cy", f('age'));

circle.exit().transition().duration(300)
    .attr('opacity', 0)
    .remove();



function createSVG() {
    var svg = d3.select('#playground').selectAll('svg').data([0]);
    svg.enter().append('svg').attr('viewBox', '150, 10, 30, 35');
    return svg;
}

function bmi(datum) {
    return datum.weight / Math.pow(datum.height/100, 2);
}
