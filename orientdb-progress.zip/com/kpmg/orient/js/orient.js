
// System
var systemData = orientdb.query('select from System');
var systemDataString = JSON.stringify(systemData);
//alert(systemDataString);
//console.log(systemDataString);


// TableShare
var tableShareData = orientdb.query('select expand(out()) from System');
var tableShareDataString = JSON.stringify(tableShareData);
//alert(tableShareDataString);
//console.log(tableShareDataString);


// Files
var fileData = orientdb.query('select expand(out()) from TableShare');
var fileDataString = JSON.stringify(fileData);
//alert(fileDataString);
//console.log(fileDataString);

// Fields
var fieldData = orientdb.query('select expand(out()) from Files');
var fieldDataString = JSON.stringify(fieldData);
//alert(fieldDataString);
//// build diagram

var units = "Widgets";

var margin = {top: 10, right: 10, bottom: 10, left: 10},
    width = 1200 - margin.left - margin.right,
    height = 740 - margin.top - margin.bottom;

var formatNumber = d3.format(",.0f"),    // zero decimal places
    format = function(d) { return formatNumber(d) + " " + units; },
    color = d3.scale.category20();

// append the svg canvas to the page
var svg = d3.select("#chart").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

// Set the sankey diagram properties
var sankey = d3.sankey()
    .nodeWidth(36)
    .nodePadding(10)
    .size([width, height]);

var path = sankey.link();






orientdb.close();
